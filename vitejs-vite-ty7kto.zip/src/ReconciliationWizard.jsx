import React, { useState } from 'react';
import SchemaConfigurationTable from './SchemaConfigurationTable';

const ReconciliationWizard = () => {
  const [step, setStep] = useState(1);
  const [reconciliationType, setReconciliationType] = useState('');
  const [schema, setSchema] = useState([]);

  const handleReconciliationTypeChange = (e) => {
    setReconciliationType(e.target.value);
  };

  const handleSchemaChange = (newSchema) => {
    setSchema(newSchema);
  };

  const handleNext = () => {
    setStep(step + 1);
  };

  const handleFinish = () => {
    console.log('Finished with schema:', schema);
    // Here you would typically send the schema to your backend or process it further
  };

  const styles = {
    container: {
      maxWidth: '800px',
      margin: '0 auto',
      padding: '20px',
    },
    card: {
      backgroundColor: 'white',
      borderRadius: '8px',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
      padding: '20px',
    },
    title: {
      fontSize: '24px',
      fontWeight: 'bold',
      marginBottom: '20px',
    },
    label: {
      display: 'block',
      marginBottom: '5px',
    },
    select: {
      width: '100%',
      padding: '5px',
      marginBottom: '10px',
    },
    button: {
      padding: '10px 20px',
      backgroundColor: '#007bff',
      color: 'white',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
    },
    disabledButton: {
      backgroundColor: '#cccccc',
      cursor: 'not-allowed',
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>Reconciliation Wizard</h2>
        {step === 1 && (
          <div>
            <label style={styles.label}>Reconciliation Type</label>
            <select
              value={reconciliationType}
              onChange={handleReconciliationTypeChange}
              style={styles.select}
            >
              <option value="">Select reconciliation type</option>
              <option value="settlement">Settlement Reconciliation</option>
            </select>
            <button
              onClick={handleNext}
              disabled={!reconciliationType}
              style={{
                ...styles.button,
                ...(reconciliationType ? {} : styles.disabledButton),
              }}
            >
              Next
            </button>
          </div>
        )}
        {step === 2 && (
          <div>
            <h3 style={{ ...styles.title, fontSize: '20px' }}>
              Configure Schema
            </h3>
            <SchemaConfigurationTable
              initialSchema={schema}
              onSchemaChange={handleSchemaChange}
            />
            <button onClick={handleFinish} style={styles.button}>
              Finish
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReconciliationWizard;
