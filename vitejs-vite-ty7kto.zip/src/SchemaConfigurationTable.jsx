import React, { useState } from 'react';

const SchemaConfigurationTable = ({ initialSchema, onSchemaChange }) => {
  const [schema, setSchema] = useState(initialSchema || []);

  const handleAddRow = () => {
    setSchema([
      ...schema,
      {
        source: { name: '', type: '', required: false },
        transformation: '',
        destination: { name: '', type: '', required: false },
      },
    ]);
  };

  const handleRemoveRow = (index) => {
    const newSchema = schema.filter((_, i) => i !== index);
    setSchema(newSchema);
    onSchemaChange(newSchema);
  };

  const handleChange = (index, field, subfield, value) => {
    const newSchema = [...schema];
    if (subfield) {
      newSchema[index][field][subfield] = value;
    } else {
      newSchema[index][field] = value;
    }
    setSchema(newSchema);
    onSchemaChange(newSchema);
  };

  const styles = {
    table: {
      width: '100%',
      borderCollapse: 'collapse',
      marginBottom: '20px',
    },
    th: {
      padding: '10px',
      textAlign: 'left',
      borderBottom: '1px solid #ddd',
    },
    td: {
      padding: '10px',
      borderBottom: '1px solid #ddd',
    },
    input: {
      width: '100%',
      padding: '5px',
      marginBottom: '5px',
    },
    select: {
      width: '100%',
      padding: '5px',
      marginBottom: '5px',
    },
    button: {
      padding: '5px 10px',
      backgroundColor: '#007bff',
      color: 'white',
      border: 'none',
      cursor: 'pointer',
    },
    removeButton: {
      padding: '5px 10px',
      backgroundColor: '#dc3545',
      color: 'white',
      border: 'none',
      cursor: 'pointer',
    },
  };

  return (
    <div>
      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.th}>Source Column</th>
            <th style={styles.th}>Transformation</th>
            <th style={styles.th}>Destination Column</th>
            <th style={styles.th}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {schema.map((row, index) => (
            <tr key={index}>
              <td style={styles.td}>
                <input
                  type="text"
                  placeholder="Name"
                  value={row.source.name}
                  onChange={(e) =>
                    handleChange(index, 'source', 'name', e.target.value)
                  }
                  style={{
                    ...styles.input,
                    borderColor: row.source.required ? 'red' : '#ddd',
                  }}
                />
                <select
                  value={row.source.type}
                  onChange={(e) =>
                    handleChange(index, 'source', 'type', e.target.value)
                  }
                  style={styles.select}
                >
                  <option value="">Select Type</option>
                  <option value="string">String</option>
                  <option value="number">Number</option>
                  <option value="date">Date</option>
                </select>
                <label>
                  <input
                    type="checkbox"
                    checked={row.source.required}
                    onChange={(e) =>
                      handleChange(
                        index,
                        'source',
                        'required',
                        e.target.checked
                      )
                    }
                  />
                  Required
                </label>
              </td>
              <td style={styles.td}>
                <select
                  value={row.transformation}
                  onChange={(e) =>
                    handleChange(index, 'transformation', null, e.target.value)
                  }
                  style={styles.select}
                >
                  <option value="">Select Transformation</option>
                  <option value="copy">Copy</option>
                  <option value="uppercase">Uppercase</option>
                  <option value="lowercase">Lowercase</option>
                  <option value="dateFormat">Date Format</option>
                </select>
              </td>
              <td style={styles.td}>
                <input
                  type="text"
                  placeholder="Name"
                  value={row.destination.name}
                  onChange={(e) =>
                    handleChange(index, 'destination', 'name', e.target.value)
                  }
                  style={{
                    ...styles.input,
                    borderColor: row.destination.required ? 'red' : '#ddd',
                  }}
                />
                <select
                  value={row.destination.type}
                  onChange={(e) =>
                    handleChange(index, 'destination', 'type', e.target.value)
                  }
                  style={styles.select}
                >
                  <option value="">Select Type</option>
                  <option value="string">String</option>
                  <option value="number">Number</option>
                  <option value="date">Date</option>
                </select>
                <label>
                  <input
                    type="checkbox"
                    checked={row.destination.required}
                    onChange={(e) =>
                      handleChange(
                        index,
                        'destination',
                        'required',
                        e.target.checked
                      )
                    }
                  />
                  Required
                </label>
              </td>
              <td style={styles.td}>
                <button
                  onClick={() => handleRemoveRow(index)}
                  style={styles.removeButton}
                >
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={handleAddRow} style={styles.button}>
        Add Row
      </button>
    </div>
  );
};

export default SchemaConfigurationTable;
